import torch
import numpy as np
from collections import OrderedDict
import sys 
sys.path.append("..") 

from models.network_dncnn import DnCNN as Net

if torch.cuda.is_available():
    device = 'cuda'
else:
    device = 'cpu'
print('device = ', device)


pth = {}
pth[6] = "denoising/dncnn_Gaussian_006_DIV2KHR_gray/models/220000_G.pth"
pth[8] = "denoising/dncnn_Gaussian_008_DIV2KHR_gray/models/428000_G.pth"
pth[10]  = "denoising/dncnn_Gaussian_01_DIV2KHR_gray/models/450000_G.pth"
# pth[10]  = "denoising/dncnn_Gaussian_01_DIV2KHR_gray/models/300000_G.pth"

pth[12] = "denoising/dncnn_Gaussian_012_DIV2KHR_gray/models/294000_G.pth"
pth[14] = "denoising/dncnn_Gaussian_014_DIV2KHR_gray/models/292000_G.pth"
pth[16] = "denoising/dncnn_Gaussian_016_DIV2KHR_gray/models/286000_G.pth"
pth[18] = "denoising/dncnn_Gaussian_018_DIV2KHR_gray/models/286000_G.pth"
pth[20] = "denoising/dncnn_Gaussian_02_DIV2KHR_gray/models/158000_G.pth"

models = {}
for noise_level in pth:
    try:
        models[noise_level] = Net(in_nc=1, out_nc=1, nc=64, nb=17, act_mode='BR')
        models[noise_level].load_state_dict(torch.load(pth[noise_level]), strict=True)
    except:
        models[noise_level] = Net(in_nc=1, out_nc=1, nc=64, nb=17, act_mode='R')
        old_para_dict = torch.load(pth[noise_level])
        para_dict = OrderedDict()
        i = 0
        for old_key in old_para_dict:
            new_key = 'model.' + str(i//2*2)
            if i % 2:
                new_key += '.bias'
            else:
                new_key += '.weight'
            para_dict[new_key] = old_para_dict[old_key]
            # print(new_key, "  <====  ", old_key)
            i += 1
        models[noise_level].load_state_dict(para_dict, strict=True)   

    for k, v in models[noise_level].named_parameters():
        v.requires_grad = False
    models[noise_level] = models[noise_level].to(device)
    models[noise_level].eval()

def dncnn(x, sigma):
    '''
    sigma = 5, 10, 15, 20, 25, 30
    x.shape = (H, W)
    x[i,j] \in [0, 1]
    '''
    x = np.array(x)
    x = torch.tensor(x, dtype=torch.float, device=device).unsqueeze(0).unsqueeze(0)
    x = x.to(device)
    sigma = int(sigma)
    # print(sigma)
    model = models[sigma]
    pre = model(x).cpu()
    return pre[0][0].detach().numpy()

class DnCNN_running(torch.nn.Module):
    def __init__(self):
        super(DnCNN_running, self).__init__()
        self.models = {}
        for level in models:
            self.models[level] = models[level]
            self.models[level].eval()
    
    def to(self, device):
        for level in models:
            self.models[level].to(device)    

    def forward(self, x, sigma):
        return self.models[sigma](x)

if __name__ == '__main__':
    x = torch.randn((32,32))
    dncnn(x, 8)