clear all;
close all;
addpath('proximity operator');
addpath('proximity operator/utils');
addpath('proximity operator/nonconvex');
file_path = 'testsets/set12/';
out_path = 'CPnPM_Cubic_set12_noise20/';




img_path_list = dir(strcat(file_path,'*.png'));
psnr_img = [];
ssim_img = [];
lambda_img = [];

gamma = 25.5;


%% img1 in set12, cameraman

% Here, lambda is acturally lambda/beta in the paper.
% level is the denoise strength.
% (level, lambda) should be chosen carefully.
level = 10; alpha = 6.5; lambda = 1580; r = 3;
% (*,*,*) = (lambda,alpha,r).


for i = 1:1
        i
        img_name = img_path_list(i).name;
        I = double(imread([file_path img_name]));
        randn('seed',1);
        eta1 = randn(size(I));
        eta2 = randn(size(I));
        noise = gamma.*eta1./eta2;
        f = I + noise;
        f = max(min(f,10000),-10000);
        [m,n] = size(I);
        [u,uu,mm,muu_CPnP_mask,meduu, u_meduu]= CPnP_Cubic_map20230603_maptest(level,f, gamma, lambda,alpha,r);
        [psnr(u,I,255),ssim(u./255,I./255)]

end

figure,imshow([u./255,mm(:,:,end)],[0,1])

imwrite([u./255,mm(:,:,end)],'tmp1.png')

% imwrite([mm(:,:,1),mm(:,:,6),mm(:,:,11),mm(:,:,21),mm(:,:,41),mm(:,:,101)],'tmp_map.png')

imwrite([mm(:,:,1),mm(:,:,6),mm(:,:,11),mm(:,:,16),mm(:,:,21),mm(:,:,31)],'tmp_map.png')

imwrite(uint8([uu(:,:,1),uu(:,:,6),uu(:,:,11),uu(:,:,16),uu(:,:,21),uu(:,:,31)]),'tmp_uu.png')

imwrite(uint8(uu(:,:,1)),'tmp_uu1.png')
imwrite(uint8(uu(:,:,2)),'tmp_uu2.png')
imwrite(uint8(uu(:,:,3)),'tmp_uu3.png')
imwrite(uint8(uu(:,:,5)),'tmp_uu5.png')
imwrite(uint8(uu(:,:,6)),'tmp_uu6.png')
imwrite(uint8(uu(:,:,10)),'tmp_uu10.png')
imwrite(uint8(uu(:,:,11)),'tmp_uu11.png')
imwrite(uint8(uu(:,:,16)),'tmp_uu16.png')
imwrite(uint8(uu(:,:,20)),'tmp_uu20.png')
imwrite(uint8(uu(:,:,21)),'tmp_uu21.png')
imwrite(uint8(uu(:,:,30)),'tmp_uu30.png')
imwrite(uint8(uu(:,:,31)),'tmp_uu31.png')

imwrite(mm(:,:,1),'tmp_map1.png')
imwrite(mm(:,:,2),'tmp_map2.png')
imwrite(mm(:,:,3),'tmp_map3.png')
imwrite(mm(:,:,5),'tmp_map5.png')
imwrite(mm(:,:,6),'tmp_map6.png')
imwrite(mm(:,:,10),'tmp_map10.png')
imwrite(mm(:,:,11),'tmp_map11.png')
imwrite(mm(:,:,16),'tmp_map16.png')
imwrite(mm(:,:,20),'tmp_map20.png')
imwrite(mm(:,:,21),'tmp_map21.png')
imwrite(mm(:,:,30),'tmp_map30.png')
imwrite(mm(:,:,31),'tmp_map31.png')

imwrite(uint8(I),'I.png')
imwrite(uint8(f),'f.png')
imwrite(uint8([meduu(:,:,1),meduu(:,:,3),meduu(:,:,10),meduu(:,:,20),meduu(:,:,30)]),'tmp_meduu.png')
imwrite(uint8([u_meduu(:,:,1),u_meduu(:,:,3),u_meduu(:,:,10),u_meduu(:,:,20),u_meduu(:,:,30)]),'tmp_umeduu.png')



