function y=Pt(x,sel,szPatch)
y=zeros(szPatch);
tmp=mat2cell(x,sel{:});
for n=1:numel(tmp)
    y=y+tmp{n};
end