function [u, uu, mm,muu,meduu,u_meduu] = CPnP_Cubic_Map20230530(level,f, gamma, lambda,alpha,r)
    theta = 10000;
    k=0; muu=[]; 
    u = medfilt2(f); 
    % u = f;
    v = u;
    b2 = 0;
    oldu = u;
    oldv = v;
    mu = 0.5; uu = [];
    crit = []; err = 1; errr = 1; muu = []; mm = []; meduu= []; u_meduu=[];
    % f = medfilt2(f);
    while (k<31)
        oldoldv = oldv;
        oldu = u;
        oldv = v;
            k=k+1;
        % update u
        
    
        tmp = 2.*v  - u - b2;
        tmp = tmp./255;
        u = double(py.denoisor.dncnn(tmp,level)).*255;
        u = min(max(u,0),255);
        [m,n] = size(u); t=norm(oldu-u,'fro');
        
        uu(:,:,k) = u;
        oldb2 = b2;
        if k>5
        mu = norm(oldu-oldv,'fro').*mu./max(1e-5,norm(u-v,'fro'));
        b2 = b2 + oldu-u+2*(0.99)^k*mu.*(u-v);
        else
        b2 = b2 + oldu-u+2.*(1).^k.*mu.*(u-v);
    %     b2 = b2 + u - v;
        end
        muu = [muu mu];
        
                   
            if k >0 % default:>5. for parrot in JSC minor revision, >0.
                
                % medu = medfilt2(u,[r,r]);
                % z = -log(gamma^2+abs(u-medu).^2)+alpha;
                % mask = 1./(1+exp(z));
                % mask = max(mask,0.01);
                % mask = min(mask,0.99);
                


                medu = medfilt2(u,[r,r]);
                mask = 1-softmax( alpha.*log(gamma^2+(u-medu).^2) );
                mask = max(mask,0.001);

                
                % mask2 = 1-softmax( alpha.*log(gamma^2+(u'-medu').^2) );
                % mask2 = max(mask2',0.001);
                % mask = min(mask2,mask);
                meduu(:,:,k) = medu;
                u_meduu(:,:,k) = abs(u-medu);
                
            

                % mask2 = 1 - sigmoid(log(gamma^2+(u-medu).^2)-alpha);
                % mask = max(mask,mask2);
            else
                mask = 1+zeros(size(u));
            end
            final_m = 1-mask;
            final_m(1,:)  =0;
            final_m(end,:)=0;
            final_m(:,1)  =0;
            final_m(:,end)=0;

            mm(:,:,k) = final_m;
            
            v = prox_cauchy(u+b2-f,lambda.*mask./2,gamma^2)+f;
            v = min(max(v,0),255);
            vv(:,:,k) = v;
    
    
    
    
    
            if k>-1
            err = norm(u- oldu,'fro')./norm(oldu,'fro');
    
            crit = [crit err];
            end
    end




